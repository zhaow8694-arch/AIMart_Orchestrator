# Assumptions

- None