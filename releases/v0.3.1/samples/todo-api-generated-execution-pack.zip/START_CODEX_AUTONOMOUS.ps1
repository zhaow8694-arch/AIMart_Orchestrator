$ErrorActionPreference = "Stop"
$RootDir = $PSScriptRoot
Set-Location $RootDir

& (Join-Path $RootDir "scripts/run-customer-autonomous.ps1") -Mode autonomous