# Release Notes

## v0.3.1

Initial local v0.3.1 Auto-Verified Customer Pack Runtime Validation execution pack for Todo API.

### Included

- Customer root START_HERE.md and START_CODEX_* launchers
- Structured ProjectSpec
- Generated TaskQueue
- Runtime and permission policy
- Full lifecycle customer state files
- SAFE_COMMANDS, DENIED_COMMANDS, and autonomous execution policy
- Autonomous Completion Gate runtime docs
- End-to-End runtime state, phase gate, current task, morning report, and next-version handoff files
- Customer one-window runner and delivery verifier scripts
- Agent Adapter Registry output
- Independent adapter options for Codex, Claude Code, Trae, Cursor
- Local finalize scripts
- Codex target adapter with supervised, autonomous, unified autonomous, end-to-end autonomous launch profiles, and completion-gate runbook
- ZIP-ready documentation