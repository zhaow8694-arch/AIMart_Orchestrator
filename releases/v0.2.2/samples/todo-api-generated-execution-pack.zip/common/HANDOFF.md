# Handoff

This pack is generated for Codex target execution of Todo API.

Selected execution mode: unified_autonomous

Use common/TASK_QUEUE.md, runtime/PERMISSION_POLICY.yaml, runtime/SAFE_COMMANDS.md, runtime/DENIED_COMMANDS.md, runtime/AUTONOMOUS_COMPLETION_GATE.md, agent_adapters/codex/AGENTS.md, agent_adapters/codex/CODEX_UNIFIED_AUTONOMOUS_RUNBOOK.md, and agent_adapters/codex/CODEX_COMPLETION_GATE_RUNBOOK.md as the source of truth.