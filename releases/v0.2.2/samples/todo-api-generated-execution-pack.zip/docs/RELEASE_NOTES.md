# Release Notes

## v0.2.2

Initial local v0.2.2 execution pack for Todo API.

### Included

- Structured ProjectSpec
- Generated TaskQueue
- Runtime and permission policy
- SAFE_COMMANDS, DENIED_COMMANDS, and autonomous execution policy
- Autonomous Completion Gate runtime docs
- Local finalize scripts
- Codex target adapter with supervised, autonomous, unified autonomous launch profiles, and completion-gate runbook
- ZIP-ready documentation