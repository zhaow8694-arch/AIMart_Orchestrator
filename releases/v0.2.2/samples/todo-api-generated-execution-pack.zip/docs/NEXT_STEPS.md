# Next Steps

## Immediate

1. Review PROJECT_SPEC.md for accuracy.
2. Execute TASK_QUEUE.md from the first pending task.
3. Run scripts/finalize.* before delivery.
4. Review runtime/AUTONOMOUS_VERIFICATION_REPORT.md and accept delivery only when the Autonomous Completion Gate reports PASS.

## Known Limitations

- v0.2.2 is local-only.
- v0.2.2 does not include a cloud runner.
- v0.2.2 does not perform production deployment.
- v0.2.2 does not read secrets or production credentials.

## Deferred Ideas

Future versions can expand adapter coverage after Todo API v0.1 is stable.