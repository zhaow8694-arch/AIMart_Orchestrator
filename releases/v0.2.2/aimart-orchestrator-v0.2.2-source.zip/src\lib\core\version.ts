export const APP_NAME = "AIMart Orchestrator";
export const APP_VERSION = "0.2.2";
