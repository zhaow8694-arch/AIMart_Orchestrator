import { describe, expect, it } from "vitest";

import { ProjectSpecSchema } from "@/lib/schemas/core";
import { createProjectSpec } from "./project-spec";

const fixedNow = new Date("2026-06-09T00:00:00.000Z");

describe("createProjectSpec", () => {
  it("creates a valid ProjectSpec from structured form fields and discussion text", () => {
    const spec = createProjectSpec(
      {
        projectName: "Stock Desk",
        background: "A local tool for a small shop.",
        rawDiscussion: "必须支持库存录入。\nIt must export monthly reports.",
        mvpScope: "库存录入\n月度报表导出",
        forbiddenItems: "不做云端部署",
        techStackPreferences: "Next.js, TypeScript, Vitest",
        testingRequirements: "核心模块必须有单元测试",
        deliveryRequirements: "交付 ZIP 包",
        securityBoundaries: "不能读取 .env 或 SSH key"
      },
      { now: fixedNow }
    );

    expect(ProjectSpecSchema.parse(spec)).toEqual(spec);
    expect(spec.projectName).toBe("Stock Desk");
    expect(spec.mvpScope).toEqual(["库存录入", "月度报表导出"]);
    expect(spec.techStackPreferences).toEqual(["Next.js", "TypeScript", "Vitest"]);
    expect(spec.explicitRequirements).toEqual(
      expect.arrayContaining([
        "库存录入",
        "月度报表导出",
        "必须支持库存录入。",
        "It must export monthly reports."
      ])
    );
    expect(spec.inferredAssumptions).toContain(
      "Use Codex as the default v0.3.0 target adapter."
    );
    expect(spec.selectedAdapterIds).toEqual(["codex"]);
    expect(spec.executionScope).toBe("single_phase");
    expect(spec.openQuestions).toEqual([]);
  });

  it("keeps incomplete information honest with assumptions and open questions", () => {
    const spec = createProjectSpec(
      {
        projectName: "Tiny Planner",
        rawDiscussion: "Build a local MVP for planning coding tasks."
      },
      { now: fixedNow }
    );

    expect(ProjectSpecSchema.parse(spec)).toEqual(spec);
    expect(spec.projectName).toBe("Tiny Planner");
    expect(spec.rawDiscussion).toContain("local MVP");
    expect(spec.inferredAssumptions).toEqual(
      expect.arrayContaining([
        "Use the recommended local v0.3.0 stack: Next.js, TypeScript, Zod, Vitest, pnpm.",
        "Use Codex as the default v0.3.0 target adapter.",
        "Use single phase execution scope by default for v0.3.0.",
        "Use supervised execution mode by default for v0.3.0."
      ])
    );
    expect(spec.openQuestions).toEqual(
      expect.arrayContaining([
        "Confirm the MVP scope.",
        "Confirm forbidden items.",
        "Confirm testing requirements.",
        "Confirm delivery requirements.",
        "Confirm security boundaries."
      ])
    );
  });

  it("defaults to supervised mode and preserves v0.3.0 mode and scope selections", () => {
    const defaultSpec = createProjectSpec(
      {
        projectName: "Tiny Planner",
        rawDiscussion: "Build a local MVP for planning coding tasks."
      },
      { now: fixedNow }
    );
    const autonomousSpec = createProjectSpec(
      {
        projectName: "Tiny Planner",
        rawDiscussion: "Build a local MVP for planning coding tasks.",
        executionMode: "autonomous"
      },
      { now: fixedNow }
    );
    const unifiedAutonomousSpec = createProjectSpec(
      {
        projectName: "Tiny Planner",
        rawDiscussion: "Build a local MVP for planning coding tasks.",
        executionMode: "unified_autonomous"
      },
      { now: fixedNow }
    );
    const endToEndSpec = createProjectSpec(
      {
        projectName: "Tiny Planner",
        rawDiscussion: "Build a local MVP for planning coding tasks.",
        selectedAdapterIds: ["codex", "claude-code", "trae", "cursor"],
        executionScope: "end_to_end_delivery",
        executionMode: "end_to_end_autonomous"
      },
      { now: fixedNow }
    );
    const legacySpec = createProjectSpec(
      {
        projectName: "Tiny Planner",
        rawDiscussion: "Build a local MVP for planning coding tasks.",
        executionMode: "codex_only"
      },
      { now: fixedNow }
    );
    const defaultEndToEndSpec = createProjectSpec(
      {
        projectName: "Todo API",
        rawDiscussion: "Build a local MVP for planning coding tasks.",
        executionScope: "end_to_end_delivery",
        executionMode: "end_to_end_autonomous"
      },
      { now: fixedNow }
    );

    expect(defaultSpec.executionMode).toBe("supervised");
    expect(autonomousSpec.executionMode).toBe("autonomous");
    expect(unifiedAutonomousSpec.executionMode).toBe("end_to_end_autonomous");
    expect(legacySpec.executionMode).toBe("supervised");
    expect(endToEndSpec.selectedAdapterIds).toEqual([
      "codex",
      "claude-code",
      "trae",
      "cursor"
    ]);
    expect(endToEndSpec.executionScope).toBe("end_to_end_delivery");
    expect(endToEndSpec.executionMode).toBe("end_to_end_autonomous");
    expect(defaultEndToEndSpec.selectedAdapterIds).toEqual([
      "codex",
      "claude-code",
      "trae",
      "cursor"
    ]);
    expect(defaultEndToEndSpec.inferredAssumptions).toContain(
      "Generate all supported independent target adapters for end-to-end delivery."
    );
  });
});
