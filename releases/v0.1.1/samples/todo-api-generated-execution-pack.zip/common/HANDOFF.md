# Handoff

This pack is generated for Codex target execution of Todo API.

Use common/TASK_QUEUE.md, runtime/PERMISSION_POLICY.yaml, and agent_adapters/codex/AGENTS.md as the source of truth.