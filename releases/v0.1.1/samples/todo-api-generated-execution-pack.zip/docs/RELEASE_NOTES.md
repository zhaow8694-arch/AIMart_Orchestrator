# Release Notes

## v0.1.0

Initial local execution pack for Todo API.

### Included

- Structured ProjectSpec
- Generated TaskQueue
- Runtime and permission policy
- Local finalize scripts
- Codex target adapter
- ZIP-ready documentation