# Todo API

This execution pack describes the local v0.1 delivery plan for Todo API.

## MVP Scope

- Local Todo API
- CRUD tasks
- unit tests

## Forbidden items

- No cloud runner
- no production deployment
- no remote Git push

## Task Queue

- TASK-001: Initialize target project
- TASK-002: Implement v0.1 core MVP
- TASK-003: Apply runtime and permission boundaries
- TASK-004: Add focused tests
- TASK-005: Write delivery documentation
- TASK-006: Finalize local delivery artifact

Start with docs/RUN_APP.md, then follow common/TASK_QUEUE.md in order.