# AIMart Production Launch Readiness v1.5 Master Plan

> 文件名：`AIMart_Production_Launch_Readiness_Master_Plan_v1.5.md`  
> 适用对象：Codex / Claude Code / Trae  
> 放置位置：`E:\AICapabilityTrading` 项目根目录  
> 当前基线：`AIMart Production Ready v1.4`  
> 目标：从准生产验证版本继续推进到“外部试点上线准备版本 v1.5”，完成真实上线前的最后一轮工程化、安全、部署、运营、用户流程和人工待办体系。  
> 核心原则：AI Agent 可以自动完成代码、测试、文档、模拟部署、沙箱适配、检查脚本、打包和 Git 收尾；但不得自动接入真实支付、真实客户数据、真实云账号、真实域名、真实证书、真实企业 SSO 或真实法务合规判断。

---

# 0. 本文件的作用

本文件用于让 Codex / Claude Code / Trae 从当前 AIMart v1.4 状态开始，全程无人干预地继续完善系统，直到生成：

```text
AIMart_Production_Launch_Readiness_v1.5_final.zip
```

本阶段不是“直接正式生产上线”，而是：

```text
外部试点上线准备
External Pilot Launch Readiness
```

也就是让系统具备：

```text
1. 可以部署到预发布 / 外部试点环境的工程结构。
2. 可以给少量测试客户演示和试用的产品流程。
3. 可以由人工接入真实域名、证书、云数据库、支付沙箱、SSO 的清晰指引。
4. 所有高风险真实操作仍由人工确认。
```

---

# 1. 当前基线状态

当前 AIMart 已完成 v1.4：

```text
后端 FastAPI
前端买家端
管理后台
商家流程
平台运营流程
AI Agent 流程
Mock Payment / Mock Escrow / Mock Budget Ledger
API Key / Header Sandbox Auth
RBAC 配置
SQLite / SQLModel
PostgreSQL 迁移路径
Docker / CI / prod-sim 配置
审计链 verified
Security baseline pass
UI/API smoke pass
E2E deterministic fallback pass
最终 zip、Git commit、tag 已生成
```

v1.4 仍然不是正式生产，因为：

```text
真实支付未接入
真实企业认证未接入
真实客户数据未接入
真实云资源未接入
真实域名和证书未配置
WORM / 外部签名归档未接入
企业级 SAST / DAST / 合规终审未完成
```

---

# 2. 本阶段名称

```text
AIMart Production Launch Readiness v1.5
```

中文名称：

```text
AIMart 外部试点上线准备阶段 v1.5
```

---

# 3. 最终交付目标

最终必须生成：

```text
AIMart_Production_Launch_Readiness_v1.5_final.zip
```

并生成 Git 标签：

```text
v1.5-production-launch-readiness
```

本阶段最终结论必须明确回答：

```text
是否可以进入外部试点上线准备？
是否仍有人工上线前必做事项？
哪些事项阻塞正式生产上线？
```

---

# 4. 永久禁止项

无论执行到什么阶段，都必须遵守：

```text
1. 不接入真实支付。
2. 不发起真实 x402 / ACP / AP2 结算。
3. 不允许高风险能力自动执行。
4. 不处理真实客户敏感数据。
5. 不发起真实跨境数据交易。
6. 不实现算力期货、期权、杠杆、二级市场或任何金融衍生品。
7. 不把真实密钥写入代码、文档、测试、日志或 zip。
8. 不提交 .env、.venv、node_modules、数据库、日志、zip、缓存文件。
9. 不关闭审计日志。
10. 不删除关键测试。
11. 不把外部试点环境描述成正式生产环境。
12. 不绕过认证、权限、预算、风险、审计、AgentCard 校验。
```

遇到任何外部真实依赖时：

```text
不要询问用户。
不要真实接入。
生成 Adapter / Mock / Sandbox placeholder。
生成环境变量模板。
生成人工接入说明。
写入 HUMAN_ACTION_REQUIRED。
继续执行。
```

---

# 5. 必须记录为人工待办的事项

以下事项只能文档化、模板化、接口化，不得自动真实执行：

```text
真实支付商户开通
真实银行账户绑定
真实支付回调域名配置
真实企业 SSO / OAuth app 创建
真实云账号登录
真实云数据库创建
真实对象存储创建
真实域名购买
真实 DNS 配置
真实 SSL 证书签发
真实邮件 / 短信服务接入
真实客户数据导入
法律合规最终确认
安全渗透测试签署
隐私政策 / 用户协议正式发布
```

必须写入并更新：

```text
docs/HUMAN_ACTION_REQUIRED.md
docs/PRODUCTION_EXTERNAL_DEPENDENCIES.md
docs/PRODUCTION_RISK_REGISTER.md
docs/EXTERNAL_PILOT_RUNBOOK.md
```

---

# 6. v1.5 必须完成的产品能力

## 6.1 买家端外部试点流程

买家端必须能演示：

```text
1. 进入能力市场首页。
2. 看到当前环境为 External Pilot / Sandbox。
3. 搜索能力。
4. 按类型、风险等级、类目、价格区间筛选能力。
5. 查看能力详情。
6. 查看 AgentCard 摘要。
7. 查看安全边界提示。
8. 发布需求。
9. 请求报价。
10. 创建 Mock 订单。
11. 看到 Mock Payment / Mock Escrow 状态。
12. 查看里程碑。
13. 验收里程碑。
14. 提交反馈。
15. 查看 trace_id。
16. 看到高风险、跨境、算力金融化阻断原因。
```

需要新增或完善：

```text
frontend/src/pages/BuyerPage.*
frontend/src/components/
frontend/tests/
docs/BUYER_PILOT_GUIDE.md
```

---

## 6.2 商家端外部试点流程

商家端必须能演示：

```text
1. 进入商家工作台。
2. 创建能力草稿。
3. 使用 AgentCard 编辑器。
4. 校验 AgentCard。
5. 提交能力审核。
6. 查看审核状态。
7. 查看买家需求。
8. 创建报价。
9. 查看订单。
10. 提交里程碑。
11. 查看买家反馈。
12. 查看能力安全状态和风险标记。
```

需要新增或完善：

```text
frontend/src/pages/SellerPage.*
frontend/src/components/AgentCardEditor.*
frontend/tests/
docs/SELLER_PILOT_GUIDE.md
```

---

## 6.3 平台运营后台流程

管理后台必须能演示：

```text
1. 运营总览 Dashboard。
2. 能力商品审核。
3. AgentCard 审核。
4. 风险事件查看。
5. 订单查看。
6. Mock Payment / Mock Escrow / Budget Ledger 查看。
7. 审计日志查看。
8. trace_id 查询。
9. 高风险阻断查看。
10. 跨境数据阻断查看。
11. 算力金融化阻断查看。
12. 认证 / RBAC 配置查看。
13. 系统健康状态查看。
14. Production Launch Readiness Checklist 查看。
```

需要新增或完善：

```text
admin_dashboard/src/
admin_dashboard/tests/
docs/OPERATOR_PILOT_GUIDE.md
```

---

## 6.4 AI Agent 外部试点流程

AI Agent 流程必须能通过 API / 测试演示：

```text
1. Agent 搜索能力。
2. Agent 读取能力详情。
3. Agent 比较能力。
4. L1 Agent 下单被阻断。
5. L2 Agent 请求报价成功。
6. L4 Agent 预算内低风险调用成功。
7. 高风险能力被阻断。
8. 成熟度不足被阻断。
9. 预算不足被阻断。
10. 所有 Agent 行为写审计。
```

必须有测试：

```text
tests/test_agent_pilot_flow.py
```

---

# 7. 认证与权限 v1.5 要求

当前 sandbox auth 继续保留，但必须完善“外部试点认证架构”：

```text
1. API Key Sandbox Auth 可配置。
2. JWT Sandbox Auth 可配置。
3. RBAC 策略可配置。
4. 所有路由使用 ActorContext。
5. 管理后台显示当前 auth mode。
6. 外部试点环境要求 AIMART_REQUIRE_API_KEY=true。
7. 本地演示环境可以 AIMART_REQUIRE_API_KEY=false。
8. 认证失败写审计。
9. 权限拒绝写审计。
10. 真实企业 SSO 只生成 Adapter 和文档，不真实接入。
```

必须新增或更新：

```text
app/auth.py
app/security.py
app/rbac.py
config/rbac_roles.json
config/auth.external-pilot.example.env
tests/test_auth_external_pilot.py
docs/AUTH_EXTERNAL_PILOT_GUIDE.md
```

---

# 8. 支付与结算 v1.5 要求

仍然不接真实支付，但必须完善“支付沙箱接入准备”：

```text
1. PaymentProvider interface。
2. MockPaymentProvider。
3. SandboxPaymentProvider placeholder。
4. RealPaymentProvider disabled guardrail。
5. Payment callback route placeholder。
6. Payment webhook signature verification placeholder。
7. Real settlement attempt returns HTTP 403。
8. 所有资金动作写审计。
9. 管理后台能看到 Mock/Sandbox payment status。
10. 文档明确说明如何由人工接入真实支付沙箱。
```

必须新增或更新：

```text
app/payments.py
app/payment_webhooks.py
tests/test_payment_sandbox_readiness.py
docs/PAYMENT_EXTERNAL_PILOT_GUIDE.md
docs/PAYMENT_HUMAN_ACTIONS.md
```

---

# 9. 数据库与迁移 v1.5 要求

必须完善：

```text
1. SQLite local mode。
2. PostgreSQL external-pilot mode。
3. DATABASE_URL 环境变量。
4. migrations/postgres/ 可读。
5. migrations/sqlite/ 可读。
6. 数据库初始化脚本。
7. 数据库 seed 脚本。
8. 数据备份脚本。
9. 数据恢复脚本。
10. 不提交真实数据库。
```

必须新增或更新：

```text
scripts/init_database.py
scripts/seed_database.py
scripts/backup_database.py
scripts/restore_database.py
config/database.external-pilot.example.env
tests/test_database_external_pilot.py
docs/DATABASE_EXTERNAL_PILOT_GUIDE.md
```

---

# 10. 审计与合规 v1.5 要求

必须完善：

```text
1. append-only audit。
2. hash chain verification。
3. audit rotation。
4. audit archive manifest。
5. audit export。
6. audit verify script。
7. management dashboard audit integrity status。
8. WORM / external signing as human action required。
```

必须新增或更新：

```text
scripts/verify_audit_chain.py
scripts/export_audit_archive.py
scripts/build_audit_manifest.py
tests/test_audit_external_pilot.py
docs/AUDIT_EXTERNAL_PILOT_GUIDE.md
docs/WORM_AUDIT_HUMAN_ACTIONS.md
```

---

# 11. 观测与运维 v1.5 要求

必须完善：

```text
1. /health
2. /api/v1/health
3. /api/v1/health/deep
4. /api/v1/system/status
5. /api/v1/production-ready/v1.5
6. config/observability.external-pilot.json
7. logs 不提交 Git
8. 管理后台系统状态面板
9. 运行手册
10. 故障排查指南
```

必须新增或更新：

```text
app/health.py
app/observability.py
config/observability.external-pilot.json
tests/test_observability_external_pilot.py
docs/OPERATIONS_RUNBOOK.md
docs/INCIDENT_RESPONSE_GUIDE.md
```

---

# 12. Docker / 部署 v1.5 要求

必须完善：

```text
1. Dockerfile.backend
2. frontend/Dockerfile
3. admin_dashboard/Dockerfile
4. docker-compose.dev.yml
5. docker-compose.prod-sim.yml
6. docker-compose.external-pilot.yml
7. .dockerignore
8. scripts/build_external_pilot.ps1
9. scripts/start_external_pilot_local.ps1
10. scripts/run_external_pilot_checks.ps1
11. scripts/package_external_pilot_release.py
```

不需要真实云部署。

必须新增或更新：

```text
docs/EXTERNAL_PILOT_DEPLOYMENT_GUIDE.md
docs/LOCAL_EXTERNAL_PILOT_SIMULATION_GUIDE.md
```

---

# 13. CI/CD v1.5 要求

必须完善：

```text
.github/workflows/prod-readiness-ci.yml
.github/workflows/release-check.yml
.github/workflows/external-pilot-ci.yml
scripts/check_release.py
scripts/check_security_baseline.py
scripts/check_zip_contents.py
scripts/check_external_pilot_readiness.py
```

CI 必须覆盖：

```text
pytest
compileall
frontend tests
admin tests
UI/API smoke fallback
zip validation
secret pattern check
forbidden entries check
security baseline
```

---

# 14. 安全基线 v1.5 要求

必须完善本地安全基线：

```text
1. secret pattern scan。
2. forbidden file scan。
3. dependency file presence check。
4. risky keyword scan。
5. CORS wildcard false。
6. debug mode false。
7. public route check。
8. env template check。
9. payment guardrail check。
10. audit enabled check。
```

必须新增或更新：

```text
scripts/security_baseline_check.py
tests/test_security_external_pilot.py
docs/SECURITY_EXTERNAL_PILOT_REPORT.md
```

---

# 15. E2E / UI 测试 v1.5 要求

必须：

```text
1. 保留 Playwright spec。
2. 如 Playwright 可用，运行 Playwright。
3. 如 Playwright 不可用，运行 deterministic smoke fallback。
4. fallback 必须覆盖买家、商家、管理后台、Agent、审计链、阻断事件。
5. 文档说明 Playwright 不可用的原因。
```

必须新增或更新：

```text
tests/e2e/external_pilot_v1_5.spec.mjs
scripts/run_e2e_tests.py
docs/E2E_EXTERNAL_PILOT_GUIDE.md
```

---

# 16. 文档 v1.5 要求

必须更新或新增：

```text
README.md
FINAL_DELIVERY_CHECK.md
FINAL_RELEASE_CLEANUP_REPORT.md
docs/API_USAGE.md
docs/ASSUMPTIONS.md
docs/IMPLEMENTATION_REPORT.md
docs/SELF_REVIEW.md
docs/FULLSTACK_USER_GUIDE.md
docs/FULLSTACK_DEPLOYMENT_GUIDE.md
docs/FULLSTACK_TEST_REPORT.md
docs/EXTERNAL_PILOT_RUNBOOK.md
docs/EXTERNAL_PILOT_DEPLOYMENT_GUIDE.md
docs/LOCAL_EXTERNAL_PILOT_SIMULATION_GUIDE.md
docs/HUMAN_ACTION_REQUIRED.md
docs/PRODUCTION_EXTERNAL_DEPENDENCIES.md
docs/PRODUCTION_RISK_REGISTER.md
docs/SECURITY_EXTERNAL_PILOT_REPORT.md
docs/RELEASE_NOTES_v1.5_external_pilot.md
docs/PHASE9_DELIVERY_CHECK.md
```

---

# 17. 最终打包要求

生成：

```text
AIMart_Production_Launch_Readiness_v1.5_final.zip
```

备份：

```text
E:\AIMart_Production_Launch_Readiness_v1.5_final.zip
```

压缩包必须包含：

```text
app/
config/
schemas/
agent_cards/
tests/
frontend/
admin_dashboard/
docs/
scripts/
migrations/
.github/workflows/
Dockerfile.backend
docker-compose.dev.yml
docker-compose.prod-sim.yml
docker-compose.external-pilot.yml
README.md
requirements.txt
pytest.ini
.env.example
FINAL_DELIVERY_CHECK.md
```

不得包含：

```text
.venv/
node_modules/
__pycache__/
*.pyc
.pytest_cache/
codex_runs/
*.db
*.ndjson
*.log
历史 zip 包
.env
真实密钥
真实客户数据
```

---

# 18. Git 收尾要求

必须执行：

```text
1. 更新 .gitignore。
2. 移除 Git 索引中的禁入文件，但保留本地文件。
3. git add .
4. git commit -m "Deliver production launch readiness v1.5"
5. git tag -f v1.5-production-launch-readiness
6. 确认 working tree clean。
7. 生成 FINAL_RELEASE_CLEANUP_REPORT.md。
```

---

# 19. 最终完成标准

只有满足以下条件才停止：

```text
1. pytest 全部通过。
2. compileall 通过。
3. frontend tests 通过。
4. admin tests 通过。
5. UI/API smoke 通过。
6. E2E fallback 或 Playwright 通过。
7. audit chain verified。
8. security baseline 通过。
9. zip validation 通过。
10. forbidden_entries=[]。
11. Git working tree clean。
12. final zip 已生成并备份。
13. tag v1.5-production-launch-readiness 指向当前 HEAD。
14. 文档全部存在且非空。
15. 禁止项全部未实现或已阻断。
16. 真实外部依赖全部转为人工待办和文档说明。
```

---

# 20. 给 Agent 的总控执行指令

```text
请读取项目根目录中的 AIMart_Production_Launch_Readiness_Master_Plan_v1.5.md，并严格按照文件执行。

目标：从当前 AIMart Production Ready v1.4 继续完善到 AIMart Production Launch Readiness v1.5，生成 AIMart_Production_Launch_Readiness_v1.5_final.zip。

要求：
1. 全程无人干预。
2. 不要阶段性停止。
3. 不要每完成一个小版本就停。
4. 不要询问用户是否继续。
5. 不接真实支付。
6. 不接真实客户数据。
7. 不接真实云账号。
8. 不接真实域名和证书。
9. 不实现高风险自动执行。
10. 不实现算力金融衍生品。
11. 不关闭审计。
12. 不删除测试。
13. 所有外部依赖使用 Mock / Sandbox / Adapter / 文档说明。
14. 持续运行测试、自我修复、补文档、打包、Git 清理，直到最终完成标准全部满足。

最终只输出：
- 测试结果
- smoke 结果
- E2E 结果
- security baseline 结果
- final zip 路径
- Git commit
- Git tag
- 文档清单
- 人工待办
- 风险与限制
- 是否可以进入外部试点上线准备
```

---

# 21. 最终输出格式

```markdown
# AIMart Production Launch Readiness v1.5 Final Delivery

## 1. 测试结果
- pytest:
- compileall:
- frontend tests:
- admin tests:
- UI/API smoke:
- E2E:
- audit chain:
- security baseline:
- zip validation:

## 2. 最终压缩包
- 文件名:
- 路径:
- 备份路径:
- 条目数:
- 禁入项:

## 3. 已完成增强
列出认证、数据库、支付沙箱、审计、运维、Docker、CI、安全扫描、前端、后台、外部试点流程增强。

## 4. 禁止项确认
逐项说明真实支付、真实结算、高风险自动执行、真实客户数据、真实跨境数据、算力金融衍生品均未实现或已阻断。

## 5. 文档清单
列出新增和更新文档。

## 6. Git 交付状态
- commit:
- tag:
- working tree:

## 7. 人工待办
列出真实域名、真实证书、真实云账号、真实支付商户、真实 SSO、法律合规最终确认。

## 8. 风险与限制
列出仍不阻塞外部试点准备但阻塞正式生产上线的问题。

## 9. 交付结论
明确说明是否可以进入外部试点上线准备。
```

---

# 22. 现在开始

```text
现在开始执行。
不要等待用户确认。
不要阶段性停止。
持续迭代直到 AIMart_Production_Launch_Readiness_v1.5_final.zip 生成、全部测试通过、文档完成、Git 清理完成并输出最终交付摘要。
```
